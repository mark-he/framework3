package com.eagletsoft.framework.sim.node;

import com.eagletsoft.framework.sim.lang.Dialect;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BlockNode extends Node {
    private boolean closed;
    protected List<Node> children = new ArrayList<>();

    public BlockNode(String content) {
        super(content);
    }

    @Override
    public int size() {
        int s = 2;
        for (Node node : children) {
            s += node.size();
        }
        return s;
    }

    @Override
    public String explain(Dialect dialect, Map<String, Object> context) {
        Map<String, Object> blockContext = NodeHelper.newContext(context);

        StringBuilder sb = new StringBuilder();
        for (Node node : children) {
            sb.append(node.explain(dialect, blockContext));
        }
        return sb.toString();
    }

    public void add(Node node) {
        if (EndNode.class.isAssignableFrom(node.getClass())) {
            closed = true;
        } else {
            children.add(node);
        }
    }

    public boolean isClosed() {
        return closed;
    }
}
