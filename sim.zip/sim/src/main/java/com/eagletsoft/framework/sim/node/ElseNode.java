package com.eagletsoft.framework.sim.node;

import com.eagletsoft.framework.sim.lang.Dialect;

import java.util.Map;

public class ElseNode extends Node {
    public ElseNode(String content) {
        super(content);
    }

    @Override
    public int size() {
        return 1;
    }

    @Override
    public String explain(Dialect dialect, Map<String, Object> context) {
        return "";
    }
}
