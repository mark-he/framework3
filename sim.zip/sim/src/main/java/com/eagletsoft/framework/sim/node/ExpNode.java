package com.eagletsoft.framework.sim.node;

import com.eagletsoft.framework.sim.lang.Dialect;

import java.util.Map;

public class ExpNode extends Node {
    public ExpNode(String content) {
        super(content);
    }

    @Override
    public int size() {
        return 1;
    }

    @Override
    public String explain(Dialect dialect, Map<String, Object> context) {
        try {
            Object ret = dialect.explain(content, context);
            return NodeHelper.nvl(ret, "");
        } catch (Exception ex) {
            return NodeHelper.nvl(dialect.handleStringError(content, context, ex), "");
        }
    }
}
