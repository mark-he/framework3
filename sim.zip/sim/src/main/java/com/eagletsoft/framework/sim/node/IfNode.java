package com.eagletsoft.framework.sim.node;

import com.eagletsoft.framework.sim.lang.Dialect;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IfNode extends BlockNode {
    private static class Branch {
        String content;
        List<Node> children = new ArrayList<>();

        public Branch(String content) {
            this.content = content;
        }
    }

    private List<Branch> branches = new ArrayList<>();
    private Branch currentBranch;

    public IfNode (String content) {
        super(content);
        currentBranch = new Branch(content);
        branches.add(currentBranch);

    }

    @Override
    public String explain(Dialect dialect, Map<String, Object> context) {
        Map<String, Object> blockContext = NodeHelper.newContext(context);
        for (Branch branch : branches) {
            String content = branch.content.trim();
            boolean match = false;
            if ("else".equals(content)) {
                match = true;
            } else {
                String cmdStr = NodeHelper.getDetective(content);

                Object test = dialect.explain(cmdStr, context);
                if (null == test || !Boolean.class.isAssignableFrom(test.getClass())) {
                    throw new RuntimeException("If detective must return a boolean value");
                }
                match = (Boolean)test;
            }

            if (match) {
                StringBuilder sb = new StringBuilder();
                for (Node node : branch.children) {
                    sb.append(node.explain(dialect, blockContext));
                }
                return sb.toString();
            }
        }
        return "";
    }

    @Override
    public void add(Node node) {
        if (!EndNode.class.isAssignableFrom(node.getClass())) {
            if (ElseNode.class.isAssignableFrom(node.getClass())) {
                currentBranch = new Branch(node.content);
                branches.add(currentBranch);
            } else if (ElseIfNode.class.isAssignableFrom(node.getClass())) {
                currentBranch = new Branch(node.content);
                branches.add(currentBranch);
            } else {
                currentBranch.children.add(node);
            }
        }
    }
}
