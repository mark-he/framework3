package com.eagletsoft.framework.sim;

import com.eagletsoft.framework.sim.lang.Dialect;
import com.eagletsoft.framework.sim.node.BlockNode;
import com.eagletsoft.framework.sim.node.Node;
import com.eagletsoft.framework.sim.node.NodeFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SimParser implements Parser {
    private Dialect dialect;

    public SimParser(Dialect dialect) {
        this.dialect = dialect;
    }

    @Override
    public String parse(String content, Map<String, Object> context) {
        BlockNode root = compile(content);
        return root.explain(dialect, context);
    }

    private static BlockNode compile(String content) {
        List<Node> nodes = link(content);
        BlockNode root = new BlockNode(content);
        compileNode(root, nodes);
        return root;
    }

    private static void compileNode(BlockNode root, List<Node> nodes) {
        int curr = 0;
        while (curr < nodes.size()) {
            Node node = nodes.get(curr);
            if (BlockNode.class.isAssignableFrom(node.getClass())) {
                compileNode((BlockNode) node, nodes.subList(curr + 1, nodes.size()));
                if (!((BlockNode)node).isClosed()) {
                    throw new RuntimeException("Parse error at: " + curr + ", without ending of block");
                }
            }
            root.add(node);
            if (root.isClosed()) {
                break;
            }
            curr += node.size();
        }
    }

    private static List<Node> link(String content) {
        List<Node> nodes = new ArrayList<>();
        fillNodes(content, 0, nodes);
        return nodes;
    }

    private static void fillNodes(String content, int fromIndex, List<Node> nodes) {
        int index = content.indexOf("#{", fromIndex);

        if (-1 == index) {
            nodes.add(NodeFactory.createTextNode(content.substring(fromIndex)));
        } else if (index >= fromIndex) {
            if (index > fromIndex) {
                nodes.add(NodeFactory.createTextNode(content.substring(fromIndex, index)));
            }
            int endIndex = content.indexOf("}", index);
            if (endIndex > -1) {
                nodes.add(NodeFactory.createExpNode(content.substring(index + 2, endIndex)));
                fillNodes(content, endIndex + 1, nodes);
            } else {
                throw new RuntimeException("Parse error at: " + index + ", without ending brace");
            }
        }
    }


}
