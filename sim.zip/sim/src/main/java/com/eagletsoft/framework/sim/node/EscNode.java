package com.eagletsoft.framework.sim.node;

import com.eagletsoft.framework.sim.lang.Dialect;

import java.util.Map;

public class EscNode extends BlockNode {

    public EscNode(String content) {
        super(content);
    }

    @Override
    public String explain(Dialect dialect, Map<String, Object> context) {
        Map<String, Object> blockContext = NodeHelper.newContext(context);

        StringBuilder sb = new StringBuilder();
        for (Node node : children) {
            sb.append(node.explain(dialect, blockContext));
        }

        StringBuilder ret = new StringBuilder();
        for (int i = 0; i < sb.length(); i++) {
            char c = sb.charAt(i);
            if (c == '<') {
                ret.append("&lt;");
            } else if (c == '>') {
                ret.append("&gt;");
            } else if (c == '&') {
                ret.append("&amp;");
            } else if (c == ' ') {
                ret.append("&nbsp;");
            } else if (c == '\n') {
                ret.append("<br/>");
            } else {
                ret.append(c);
            }
        }
        return ret.toString();
    }
}
