package com.eagletsoft.framework.orm.repo.exec.impl;

import com.eagletsoft.framework.orm.repo.exec.RepoExecService;
import com.eagletsoft.framework.orm.repo.exec.RepoExecTemplate;
import com.eagletsoft.framework.orm.repo.naming.NamingStrategy;

import java.lang.reflect.Method;

public class RepoExecTemplateService implements RepoExecService {
    private RepoExecTemplate repoExecTemplate;

    public RepoExecTemplateService(Class entityClass, Class<? extends RepoExecTemplate> repoExecTemplateClass, NamingStrategy namingStrategy, String profile) {
        try {
            this.repoExecTemplate = repoExecTemplateClass.newInstance();
            this.repoExecTemplate.setEntityClass(entityClass);
            this.repoExecTemplate.setNamingStrategy(namingStrategy);
            this.repoExecTemplate.setProfile(profile);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public Object process(Method method, Object[] args) {
        try {
            Method targetMethod = repoExecTemplate.getClass().getMethod(method.getName(), method.getParameterTypes());
            return targetMethod.invoke(repoExecTemplate, args);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("There was no corresponding method for: " + method.getName(), e);
        } catch (Exception e) {
            throw new RuntimeException("There were errors when invoking method for: " + method.getName(), e);
        }
    }
}
