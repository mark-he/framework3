package com.eagletsoft.framework.orm.repo.exec.meta;

import com.eagletsoft.framework.orm.repo.exec.impl.ModifyExec;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Exec(ModifyExec.class)
public @interface Modify {
    String value() default "";
}
