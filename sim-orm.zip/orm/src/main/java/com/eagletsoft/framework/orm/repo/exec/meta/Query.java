package com.eagletsoft.framework.orm.repo.exec.meta;

import com.eagletsoft.framework.orm.repo.exec.impl.QueryExec;
import com.eagletsoft.framework.orm.repo.naming.NamingStrategy;
import com.eagletsoft.framework.orm.repo.naming.ReadCamelToSnakeStrategy;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Exec(QueryExec.class)
public @interface Query {
    String value() default "";
    Class<? extends NamingStrategy> namingStrategy() default ReadCamelToSnakeStrategy.class;
    int limit() default 0;
}
