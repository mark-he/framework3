package com.eagletsoft.framework.orm.entity.inject.meta;

import com.eagletsoft.framework.orm.entity.inject.impl.TruncInjector;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@EntityInject(injectedBy = TruncInjector.class)
public @interface Trunc {
    int value() default 0;
}
