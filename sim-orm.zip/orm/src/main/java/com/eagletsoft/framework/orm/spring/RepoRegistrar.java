package com.eagletsoft.framework.orm.spring;

import com.eagletsoft.framework.orm.repo.meta.EnableRepo;
import com.eagletsoft.framework.orm.repo.meta.Repo;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.filter.AnnotationTypeFilter;

import javax.annotation.Resource;
import java.lang.annotation.Annotation;
import java.util.Map;

public class RepoRegistrar implements ImportBeanDefinitionRegistrar, ResourceLoaderAware, EnvironmentAware {
    private Environment environment;
    private ResourceLoader resourceLoader;

    protected Class<? extends Annotation> getAnnotation() {
        return EnableRepo.class;
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }

    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    @Override
    public void registerBeanDefinitions(AnnotationMetadata annotationMetadata, BeanDefinitionRegistry beanDefinitionRegistry) {
        Class annotation = getAnnotation();
        Map<String, Object> annotationAttributes = annotationMetadata.getAnnotationAttributes(annotation.getName());

        if (null == annotationAttributes) {
            throw new IllegalStateException(String.format("Unable to obtain annotation attributes for %s!", annotation));
        }

        String[] basePackages = (String[])annotationAttributes.get("basePackages");
        RepoScanner scanner = new RepoScanner(beanDefinitionRegistry);
        scanner.setEnvironment(environment);
        scanner.setResourceLoader(resourceLoader);
        scanner.addIncludeFilter(new AnnotationTypeFilter(Repo.class));
        scanner.scan(basePackages);
    }
}
