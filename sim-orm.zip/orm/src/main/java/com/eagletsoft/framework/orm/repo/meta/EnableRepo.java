package com.eagletsoft.framework.orm.repo.meta;

import com.eagletsoft.framework.orm.spring.RepoRegistrar;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@Import(RepoRegistrar.class)
public @interface EnableRepo {
    String[] basePackages() default {};
}
