package com.eagletsoft.framework.orm.repo.exec;

public interface SqlParam {
}
