package com.eagletsoft.framework.orm.entity.inject.meta;

public class Operations {
    public static final int CREATE = 1;
    public static final int UPDATE = 2;

    private Operations() {}
}
