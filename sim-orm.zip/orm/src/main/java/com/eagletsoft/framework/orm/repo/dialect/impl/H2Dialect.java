package com.eagletsoft.framework.orm.repo.dialect.impl;

import com.eagletsoft.framework.orm.repo.dialect.Dialect;
import com.eagletsoft.framework.orm.repo.paging.PageReq;

public class H2Dialect implements Dialect {
    @Override
    public String getPagingSQL(String sql, PageReq pageReq) {
        StringBuilder sb = new StringBuilder(sql);
        sb.append(String.format(" limit %s offset %s", pageReq.getSize(), pageReq.getIndex() * pageReq.getSize()));
        return sb.toString();
    }
}
