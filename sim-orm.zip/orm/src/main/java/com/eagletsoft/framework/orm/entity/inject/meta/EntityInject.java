package com.eagletsoft.framework.orm.entity.inject.meta;

import com.eagletsoft.framework.orm.entity.inject.EntityInjector;

import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.ANNOTATION_TYPE)
public @interface EntityInject {
    Class<? extends EntityInjector> injectedBy();
}
