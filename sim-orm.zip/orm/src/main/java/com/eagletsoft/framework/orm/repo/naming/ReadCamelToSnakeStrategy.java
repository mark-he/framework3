package com.eagletsoft.framework.orm.repo.naming;

public class ReadCamelToSnakeStrategy implements NamingStrategy {

    @Override
    public String read(String name) {
        return NamingUtils.convertSnakeToCamel(name);
    }

    @Override
    public String write(String name) {
        return NamingUtils.convertCamelToSnake(name);
    }
}
