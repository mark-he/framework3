package com.eagletsoft.framework.orm.entity.inject.impl;

import com.eagletsoft.framework.orm.entity.inject.EntityInjector;
import com.eagletsoft.framework.orm.entity.inject.meta.IdGenerator;

public class IdGeneratorInjector implements EntityInjector<IdGenerator, Object> {

    @Override
    public Object getInjectValue(IdGenerator annotation, Class type, Object value) {
        if (null == value || value.toString().isEmpty()) {
            value = new UUIDHexGenerator().generate();
        }
        return value;
    }
}
