package com.eagletsoft.framework.orm.repo.exec.meta;

import com.eagletsoft.framework.orm.repo.exec.impl.RepoExecAnnotationService;

import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface Exec {
    Class<? extends RepoExecAnnotationService> value();
}
