package com.eagletsoft.framework.orm.repo.dialect;

import com.eagletsoft.framework.orm.repo.paging.PageReq;

public interface Dialect {
    String getPagingSQL(String sql, PageReq pageReq);
}
