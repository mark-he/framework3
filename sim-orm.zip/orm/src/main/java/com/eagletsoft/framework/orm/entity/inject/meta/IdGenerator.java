package com.eagletsoft.framework.orm.entity.inject.meta;

import com.eagletsoft.framework.orm.entity.inject.impl.IdGeneratorInjector;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@EntityInject(injectedBy = IdGeneratorInjector.class)
public @interface IdGenerator {
    String algo() default "UUID";
    int operation() default Operations.CREATE;
}
