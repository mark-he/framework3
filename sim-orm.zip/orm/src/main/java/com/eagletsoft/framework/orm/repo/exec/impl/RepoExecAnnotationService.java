package com.eagletsoft.framework.orm.repo.exec.impl;

import com.eagletsoft.framework.orm.repo.dialect.Dialect;
import com.eagletsoft.framework.orm.repo.exec.RepoExecService;
import com.eagletsoft.framework.orm.repo.naming.NamingStrategy;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.HashMap;
import java.util.Map;

public abstract class RepoExecAnnotationService implements RepoExecService {
    protected Map<String, Object> annConfig;
    protected NamingStrategy namingStrategy;
    protected String profile;
    protected Dialect dialect;

    public void setAnnConfig(Map<String, Object> annConfig) {
        this.annConfig = annConfig;
    }

    public void setNamingStrategy(NamingStrategy namingStrategy) {
        this.namingStrategy = namingStrategy;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public void setDialect(Dialect dialect) {
        this.dialect = dialect;
    }

    protected Map<String, Object> getMethodParameters(Method method, Object[] args) {
        Parameter[] parameters = method.getParameters();
        Map<String, Object> ret = new HashMap<>();

        for (int i = 0; i < parameters.length; i++) {
            ret.put(parameters[i].getName(), args[i]);
        }
        return ret;
    }
}
