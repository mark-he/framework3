package com.eagletsoft.framework.orm.entity.inject;

public interface EntityInjector<A, T> {
    T getInjectValue(A annotation, Class type, T value);
}
