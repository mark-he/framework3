package com.eagletsoft.framework.orm.repo.exec.impl;

import com.eagletsoft.framework.orm.entity.inject.InjectHelper;
import com.eagletsoft.framework.orm.entity.inject.meta.Operations;
import com.eagletsoft.framework.orm.repo.exec.CrudRepo;
import com.eagletsoft.framework.orm.repo.exec.RepoExecTemplate;
import com.eagletsoft.framework.orm.repo.jdbc.JdbcHelperFactory;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import java.beans.Transient;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CrudRepoExecTemplate extends RepoExecTemplate implements CrudRepo {
    @Override
    public int update(Object data) {
        try {
            InjectHelper.inject(data, Operations.UPDATE);
            String[] fieldNames = getFieldNames(data.getClass(), idName);
            Map<String, Object> params = new HashMap<>();
            StringBuilder valuesParamStr = new StringBuilder();
            for (int i = 0; i < fieldNames.length; i++) {
                String paramName = ":" + fieldNames[i];
                params.put(fieldNames[i], PropertyUtils.getProperty(data, fieldNames[i]));
                if (valuesParamStr.length() > 0) {
                    valuesParamStr.append(", ");
                }
                valuesParamStr.append(namingStrategy.write(fieldNames[i]) + " = " + paramName);
            }
            params.put(idName, PropertyUtils.getProperty(data, idName));
            String sql = String.format("UPDATE %s SET %s WHERE %s = :%s", table.value(), valuesParamStr, namingStrategy.write(idName), idName);
            return JdbcHelperFactory.getInstance().create(profile).update(sql, params);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void create(Object data) {
        try {
            InjectHelper.inject(data, Operations.CREATE);
            String[] fieldNames = getFieldNames(data.getClass());
            String fieldNameStr = StringUtils.arrayToDelimitedString(fieldNames, ",");

            Map<String, Object> params = new HashMap<>();
            StringBuilder valuesParamStr = new StringBuilder();
            for (int i = 0; i < fieldNames.length; i++) {
                String paramName = ":" + fieldNames[i];
                params.put(fieldNames[i], PropertyUtils.getProperty(data, fieldNames[i]));
                if (valuesParamStr.length() > 0) {
                    valuesParamStr.append(", ");
                }
                valuesParamStr.append(paramName);
            }
            String sql = String.format("INSERT INTO %s (%s) VALUES(%s)", table.value(), namingStrategy.write(fieldNameStr), valuesParamStr.toString());
            JdbcHelperFactory.getInstance().create(profile).update(sql, params);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public int deleteById(Serializable id) {
        String sql = String.format("DELETE FROM %s WHERE %s = :id", table.value(), namingStrategy.write(idName));
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        return JdbcHelperFactory.getInstance().create(profile).update(sql, params);
    }

    @Override
    public Object findById(Serializable id) {
        String[] fieldNames = getFieldNames(entityClass);
        String fieldNameStr = StringUtils.arrayToDelimitedString(fieldNames, ",");
        String sql = String.format("SELECT %s FROM %s WHERE %s = :id", namingStrategy.write(fieldNameStr), table.value(), namingStrategy.write(idName));
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);

        List list = JdbcHelperFactory.getInstance().create(profile).query(sql, params, new BeanPropertyRowMapper<>(entityClass));
        int size = list.size();
        if (size > 1) {
            throw new RuntimeException("The specific Query was expected to return 0 or 1, but return " + size);
        }
        return size == 0 ? null : list.get(0);
    }

    protected String[] getFieldNames(Class clazz, String... ignores) {
        List<String> list = new ArrayList<>();
        ReflectionUtils.doWithFields(clazz, f -> {
            if (null == AnnotationUtils.getAnnotation(f, Transient.class)) {
                if (!ArrayUtils.contains(ignores, f.getName())) {
                    list.add(f.getName());
                }
            }
        });
        return list.toArray(new String[0]);
    }
}
