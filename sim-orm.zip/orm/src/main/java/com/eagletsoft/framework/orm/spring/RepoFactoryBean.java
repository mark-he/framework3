package com.eagletsoft.framework.orm.spring;

import com.eagletsoft.framework.orm.repo.RepoExecManager;
import org.springframework.beans.factory.FactoryBean;

import java.lang.reflect.Proxy;

public class RepoFactoryBean implements FactoryBean {
    private Class repoClass;

    public RepoFactoryBean(Class repoClass) {
        this.repoClass = repoClass;
    }

    @Override
    public Object getObject() {
        return Proxy.newProxyInstance(repoClass.getClassLoader(),
                new Class[]{repoClass},
                (proxy, method, args) -> RepoExecManager.getInstance().process(repoClass, method, args)
        );
    }

    @Override
    public Class<?> getObjectType() {return repoClass;}
}
