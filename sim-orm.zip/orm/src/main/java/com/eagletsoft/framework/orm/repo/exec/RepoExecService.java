package com.eagletsoft.framework.orm.repo.exec;

import java.lang.reflect.Method;

/*
* Database template of operations
* */
public interface RepoExecService {
    Object process(Method method, Object[] args);
}
