package com.eagletsoft.framework.orm.repo.exec.impl;

import com.eagletsoft.framework.orm.mapper.MapperLoader;
import com.eagletsoft.framework.orm.repo.jdbc.JdbcHelper;
import com.eagletsoft.framework.orm.repo.jdbc.JdbcHelperFactory;
import com.eagletsoft.framework.orm.repo.paging.Page;
import com.eagletsoft.framework.orm.repo.paging.PageReq;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SingleColumnRowMapper;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import java.beans.Transient;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.*;

public class QueryExec extends RepoExecAnnotationService {
    private boolean isSingleColumnView(Class dataType) {
        return dataType.isPrimitive()
                || Number.class.isAssignableFrom(dataType)
                || Boolean.class.isAssignableFrom(dataType)
                || Date.class.isAssignableFrom(dataType)
                || CharSequence.class.isAssignableFrom(dataType)
                || BigDecimal.class.isAssignableFrom(dataType);
    }

    @Override
    public Object process(Method method, Object[] args) {
        String sql = (String)annConfig.get("value");
        if (StringUtils.isEmpty(sql)) {
            sql = MapperLoader.getInstance().getSql(method.getDeclaringClass().getName(), method.getName());
        }
        int limit = (Integer)annConfig.get("limit");

        String countSql = null;
        JdbcHelper jdbcHelper = JdbcHelperFactory.getInstance().create(profile);
        Map<String, Object> parameters = getMethodParameters(method, args);

        Iterator<Map.Entry<String, Object>> it = parameters.entrySet().iterator();
        PageReq pageReq = null;
        while (it.hasNext()) {
            Map.Entry<String, Object> entry = it.next();
            if (entry.getValue() instanceof PageReq) {
                pageReq = (PageReq) entry.getValue();
                it.remove();
            }
        }

        if (null == pageReq) {
            if (limit > 0) {
                pageReq = new PageReq(0, limit);
            }
        }
        if (null != pageReq) {
            countSql = makeCountSQL(sql);
            sql = JdbcHelperFactory.getInstance().create(profile).getDialect().getPagingSQL(sql, pageReq);
        }
        Class dataType = method.getReturnType();
        if (Collection.class.isAssignableFrom(method.getReturnType())) {
            dataType = getReturnViewType(method);
        } else if (Page.class.isAssignableFrom(dataType)) {
            dataType = getReturnViewType(method);
            if (null == pageReq) {
                throw new RuntimeException("Missing PageReq");
            }
        }

        RowMapper rowMapper;
        if (isSingleColumnView(dataType)) {
            rowMapper = new SingleColumnRowMapper(dataType);
        } else {
            if (Map.class.isAssignableFrom(dataType)) {
                rowMapper = new ColumnMapRowMapper() {
                    @Override
                    protected String getColumnKey(String columnName) {
                        return namingStrategy.read(columnName);
                    }
                };
            } else {
                rowMapper = new BeanPropertyRowMapper<>(dataType);
                ((BeanPropertyRowMapper)rowMapper).setPrimitivesDefaultedForNullValue(true);

                String[] fieldNames = getFieldNames(dataType);
                String fieldNameStr = StringUtils.arrayToDelimitedString(fieldNames, ",");
                sql = sql.replace("*", this.namingStrategy.write(fieldNameStr));
            }
        }

        if (Page.class.isAssignableFrom(method.getReturnType())) {
            Page page = new Page();
            page.setIndex(pageReq.getIndex());
            page.setSize(pageReq.getSize());

            Integer count = jdbcHelper.queryForObject(countSql, parameters, Integer.class);
            if (count > 0) {
                List list = jdbcHelper.query(sql, parameters, rowMapper);
                page.setList(list);
                page.setTotal(count);
            }
            return page;
        } else {
            List list = jdbcHelper.query(sql, parameters, rowMapper);
            if (Collection.class.isAssignableFrom(method.getReturnType())) {
                return list;
            } else {
                int size = list.size();
                if (size > 1) {
                    throw new RuntimeException("The specific Query was expected to return 0 or 1, but return: " + size);
                }
                return size == 0 ? null : list.get(0);
            }
        }
    }

    protected String[] getFieldNames(Class clazz, String... ignores) {
        List<String> list = new ArrayList<>();
        ReflectionUtils.doWithFields(clazz, f -> {
            if (null == AnnotationUtils.getAnnotation(f, Transient.class)) {
                if (!ArrayUtils.contains(ignores, f.getName())) {
                    list.add(f.getName());
                }
            }
        });
        return list.toArray(new String[0]);
    }

    private Class getReturnViewType(Method method) {
        Type genericReturnType = method.getGenericReturnType();
        if (genericReturnType instanceof ParameterizedType) {
            Type[] actualTypeArguments = ((ParameterizedType)genericReturnType).getActualTypeArguments();
            if (actualTypeArguments.length > 0) {
                return (Class)actualTypeArguments[0];
            }
        }
        return HashMap.class;
    }

    private String makeCountSQL(String sql) {
        int fromIndex = sql.toUpperCase().indexOf("FROM");
        return String.format("SELECT COUNT(1) %s", sql.substring(fromIndex));
    }
}
