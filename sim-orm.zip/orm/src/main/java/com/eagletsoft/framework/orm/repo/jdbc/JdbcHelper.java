package com.eagletsoft.framework.orm.repo.jdbc;

import com.eagletsoft.framework.orm.repo.dialect.Dialect;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.List;
import java.util.Map;

public class JdbcHelper {
    private Dialect dialect;
    private NamedParameterJdbcTemplate jdbcTemplate;

    public JdbcHelper(Dialect dialect, JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
        this.dialect = dialect;
    }

    public Dialect getDialect() {
        return dialect;
    }

    public void setDialect(Dialect dialect) {
        this.dialect = dialect;
    }

    public NamedParameterJdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public <T> List<T> query(String sql, Map<String, ?> paramMap, RowMapper<T> rowMapper) {
        return jdbcTemplate.query(sql, new EnhanceMapParameterSource(paramMap), rowMapper);
    }

    public <T> T queryForObject(String sql, Map<String, ?> paramMap, Class<T> requiredType) throws DataAccessException {
        return jdbcTemplate.queryForObject(sql, new EnhanceMapParameterSource(paramMap), requiredType);
    }

    public List<Map<String, Object>> queryForList(String sql, Map<String, ?> paramMap) {
        return jdbcTemplate.queryForList(sql, new EnhanceMapParameterSource(paramMap));
    }

    public int update(String sql, Map<String, ?> paramMap) throws DataAccessException {
        return jdbcTemplate.update(sql, new EnhanceMapParameterSource(paramMap));
    }
}
