package com.eagletsoft.framework.sim.node;

import com.eagletsoft.framework.sim.lang.Dialect;

import java.util.Map;

public abstract class Node {
    protected String content;

    public Node(String content) {
        this.content = content;
    }

    public abstract int size();
    public abstract String explain(Dialect dialect, Map<String, Object> context);

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
