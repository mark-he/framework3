package com.eagletsoft.framework.sim.node;

import com.eagletsoft.framework.sim.lang.Dialect;

import java.util.Map;

public class ForNode extends BlockNode {
    public ForNode(String content) {
        super(content);
    }

    @Override
    public String explain(Dialect dialect, Map<String, Object> context) {
        Map<String, Object> blockContext = NodeHelper.newContext(context);

        String tempContent = NodeHelper.getDetective(content);
        int inIdx = tempContent.indexOf(" in ");
        if (-1 == inIdx) {
            throw new RuntimeException("For detective must be in format: for item in list");
        }

        String itemStr = tempContent.substring(0, inIdx).trim();
        String listStr = tempContent.substring(inIdx + 4).trim();

        Object iter = dialect.explain(listStr, context);
        if (null == iter) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        if (Iterable.class.isAssignableFrom(iter.getClass())) {
            for (Object item : (Iterable)iter) {
                blockContext.put(itemStr, item);
                for (Node node : children) {
                    sb.append(node.explain(dialect, blockContext));
                }
            }
        } else if (Number.class.isAssignableFrom(iter.getClass())) {
            for (int i = 0; i < ((Number)iter).intValue(); i++) {
                blockContext.put(itemStr, i);
                for (Node node : children) {
                    sb.append(node.explain(dialect, blockContext));
                }
            }
        } else {
            throw new RuntimeException("For detective must loop a list or a number");
        }
        return sb.toString();
    }
}
