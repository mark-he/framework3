package com.eagletsoft.framework.sim.node;

public class NodeFactory {

    private static final String DETECTIVE_FOR = "for";
    private static final String DETECTIVE_IF = "if";
    private static final String DETECTIVE_ELSE = "else";
    private static final String DETECTIVE_ELSEIF = "elseif";
    private static final String DETECTIVE_END = "end";
    private static final String DETECTIVE_SET = "set";
    private static final String DETECTIVE_ESC = "esc";

    public static Node createExpNode(String content) {
        String[] cs = content.split(" ", -1);
        String type = cs[0].trim();

        if (DETECTIVE_FOR.equals(type)) {
            return new ForNode(content);
        } else if (DETECTIVE_IF.equals(type)) {
            return new IfNode(content);
        } else if (DETECTIVE_ELSE.equals(type)) {
            return new ElseNode(content);
        } else if (DETECTIVE_ELSEIF.equals(type)) {
            return new ElseIfNode(content);
        } else if (DETECTIVE_END.equals(type)) {
            return new EndNode(content);
        } else if (DETECTIVE_SET.equals(type)) {
            return new SetNode(content);
        } else if (DETECTIVE_ESC.equals(type)) {
            return new EscNode(content);
        }
        return new ExpNode(content);
    }

    public static Node createTextNode(String content) {
        return new TextNode(content);
    }
}
