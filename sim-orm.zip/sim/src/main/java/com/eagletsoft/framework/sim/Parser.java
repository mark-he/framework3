package com.eagletsoft.framework.sim;

import java.util.Map;

public interface Parser {
    String parse(String content, Map<String, Object> context);
}
