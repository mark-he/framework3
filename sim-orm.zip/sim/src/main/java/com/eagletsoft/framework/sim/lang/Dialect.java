package com.eagletsoft.framework.sim.lang;

import java.util.Map;

public interface Dialect {
    Object explain(String content, Map<String, Object> context);

    default String handleStringError(String content, Map<String, Object> context, Exception ex) {
        return "Err!!";
    }
}
