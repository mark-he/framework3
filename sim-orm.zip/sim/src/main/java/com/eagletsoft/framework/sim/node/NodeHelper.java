package com.eagletsoft.framework.sim.node;

import java.util.HashMap;
import java.util.Map;

public class NodeHelper {
    public static String getDetective(String content) {
        String tempContent = content.trim();
        int spaceIdx = tempContent.indexOf(' ');
        return tempContent.substring(spaceIdx);
    }

    public static String nvl(Object obj, String defaultStr) {
        if (null == obj) {
            return defaultStr;
        } else {
            return obj.toString();
        }
    }

    public static Map<String, Object> newContext(Map<String, Object> context) {
        Map<String, Object> newCtx = new HashMap<>();
        if (null != context) {
            newCtx.putAll(context);
        }
        return newCtx;
    }
}
