package com.eagletsoft.framework.topology.common;

public class Environment {
    private static Environment INSTANCE = new Environment();

    private Bridge bridge;

    private Environment() {

    }

    public static Environment getInstance() {
        return INSTANCE;
    }

    public void init(Bridge bridge) {
        this.bridge = bridge;
    }

    public <T> T getBean(String name, Class<T> clazz) {
        return bridge.getBean(name, clazz);
    }

    public <T> T getBean(Class<T> clazz) {
        return bridge.getBean(clazz);
    }

    public Logger getLogger() {
        return bridge.getLogger();
    }

    public interface Bridge {
        <T> T getBean(String name, Class<T> clazz);
        <T> T getBean(Class<T> clazz);
        Logger getLogger();
    }
}
