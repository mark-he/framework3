package com.eagletsoft.framework.topology.common;

public class SpecException extends RuntimeException {
    private String code = CodeEnum.RUNTIME.value;

    private Object[] params;


    public SpecException(Throwable cause) {
        super(cause);
    }

    public SpecException(String message, Throwable cause, String code, Object[] params) {
        super(message, cause);
        this.code = code;
        this.params = params;
    }
    public enum CodeEnum {
        RUNTIME("RUNTIME");
        public String value;
        CodeEnum(String value) {
            this.value = value;
        }
    }
}
