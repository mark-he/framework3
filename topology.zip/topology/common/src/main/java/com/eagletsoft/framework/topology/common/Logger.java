package com.eagletsoft.framework.topology.common;

public interface Logger {
    default void debug(String message) {
        info(message);
    };
    default void info(String message) {
        System.out.println(message);
    }
    default void warn(String message) {
        info(message);
    }
    default void error(String message, Throwable throwable) {
        info(message);
        throwable.printStackTrace();
    }
}
