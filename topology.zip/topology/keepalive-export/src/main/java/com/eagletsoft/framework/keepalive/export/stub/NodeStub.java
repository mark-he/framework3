package com.eagletsoft.framework.keepalive.export.stub;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class NodeStub implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<String> nodes = new ArrayList<>();

    public List<String> getNodes() {
        return nodes;
    }

    public void setNodes(List<String> nodes) {
        this.nodes = nodes;
    }
}
