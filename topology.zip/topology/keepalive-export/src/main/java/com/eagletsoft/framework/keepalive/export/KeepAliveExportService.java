package com.eagletsoft.framework.keepalive.export;

import com.eagletsoft.framework.keepalive.export.stub.KeepAliveStub;
import com.eagletsoft.framework.keepalive.export.stub.NodeStub;
import com.eagletsoft.framework.keepalive.export.stub.SessionStub;

public interface KeepAliveExportService {
    SessionStub login(String type, String nodeId);
    void logout(String nodeId);
    KeepAliveStub keepAlive(String nodeId, String sessionId);
    NodeStub getAliveNodes(String type);
}
