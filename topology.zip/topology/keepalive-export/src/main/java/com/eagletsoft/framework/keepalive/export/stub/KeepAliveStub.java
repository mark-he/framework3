package com.eagletsoft.framework.keepalive.export.stub;

import java.io.Serializable;
import java.util.Date;

public class KeepAliveStub implements Serializable {
    private static final long serialVersionUID = 1L;

    private String status;
    private Date lastActiveTime;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getLastActiveTime() {
        return lastActiveTime;
    }

    public void setLastActiveTime(Date lastActiveTime) {
        this.lastActiveTime = lastActiveTime;
    }
}
