package com.eagletsoft.framework.keepalive.export.stub;

import java.io.Serializable;
import java.util.Date;

public class SessionStub implements Serializable {
    private static final long serialVersionUID = 1L;

    private String sessionId;
    private long keepAliveTimeout;
    private Date createdTime;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public long getKeepAliveTimeout() {
        return keepAliveTimeout;
    }

    public void setKeepAliveTimeout(long keepAliveTimeout) {
        this.keepAliveTimeout = keepAliveTimeout;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }
}
