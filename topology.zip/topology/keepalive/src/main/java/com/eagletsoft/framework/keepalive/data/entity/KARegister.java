package com.eagletsoft.framework.keepalive.data.entity;

import com.eagletsoft.framework.orm.entity.inject.meta.CurrentTime;
import com.eagletsoft.framework.orm.entity.meta.Id;
import com.eagletsoft.framework.orm.entity.meta.Table;

import java.util.Date;

@Table("KA_REGISTER")
public class KARegister {
    private String type = TypeEnum.WORKER.value;
    @Id
    private String nodeId;
    private String sessionId;
    @CurrentTime
    private Date createdTime;
    private String role = RoleEnum.FOLLOW.value;
    private String status = StatusEnum.ACTIVE.value;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public enum StatusEnum {
        ACTIVE("ACTIVE"),
        LOGOUT("LOGOUT"),
        INACTIVE("INACTIVE");
        public String value;

        StatusEnum(String value) {
            this.value = value;
        }
    }

    public enum RoleEnum {

        LEAD("LEAD"),
        FOLLOW("FOLLOW"),
        INVALID("INVALID");
        public String value;

        RoleEnum(String value) {
            this.value = value;
        }
    }

    public enum TypeEnum {

        WORKER("WORKER");
        public String value;

        TypeEnum(String value) {
            this.value = value;
        }
    }
}
