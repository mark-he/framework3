package com.eagletsoft.framework.keepalive.data.entity;

import com.eagletsoft.framework.orm.entity.inject.meta.CurrentTime;
import com.eagletsoft.framework.orm.entity.inject.meta.IdGenerator;
import com.eagletsoft.framework.orm.entity.meta.Id;
import com.eagletsoft.framework.orm.entity.meta.Table;

import java.util.Date;

@Table("KA_SESSION")
public class KASession {
    @Id
    @IdGenerator
    private String id;
    private String type;
    private String nodeId;
    @CurrentTime
    private Date createdTime;
    @CurrentTime
    private Date lastActiveTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getLastActiveTime() {
        return lastActiveTime;
    }

    public void setLastActiveTime(Date lastActiveTime) {
        this.lastActiveTime = lastActiveTime;
    }
}
