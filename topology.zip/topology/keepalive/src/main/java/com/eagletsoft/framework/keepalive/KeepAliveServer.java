package com.eagletsoft.framework.keepalive;

public interface KeepAliveServer {
    void serve();
}
