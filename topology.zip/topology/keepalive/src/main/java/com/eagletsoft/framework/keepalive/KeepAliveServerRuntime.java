package com.eagletsoft.framework.keepalive;

import java.util.concurrent.TimeUnit;

public class KeepAliveServerRuntime {
    private long voteDelay = 1 * 1000L;

    private long votePeriod = 3 * 1000L;

    private long keepAliveTimeout = 10 * 1000L;

    private TimeUnit unit = TimeUnit.MILLISECONDS;

    public long getVoteDelay() {
        return voteDelay;
    }

    public void setVoteDelay(long voteDelay) {
        this.voteDelay = voteDelay;
    }

    public long getVotePeriod() {
        return votePeriod;
    }

    public void setVotePeriod(long votePeriod) {
        this.votePeriod = votePeriod;
    }

    public long getKeepAliveTimeout() {
        return keepAliveTimeout;
    }

    public void setKeepAliveTimeout(long keepAliveTimeout) {
        this.keepAliveTimeout = keepAliveTimeout;
    }

    public TimeUnit getUnit() {
        return unit;
    }

    public void setUnit(TimeUnit unit) {
        this.unit = unit;
    }
}
