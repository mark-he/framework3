package com.eagletsoft.framework.keepalive.repo;

import com.eagletsoft.framework.keepalive.data.entity.KASession;
import com.eagletsoft.framework.orm.repo.exec.CrudRepo;
import com.eagletsoft.framework.orm.repo.exec.meta.Modify;
import com.eagletsoft.framework.orm.repo.meta.Repo;

import java.util.Date;

@Repo(enetityClass = KASession.class)
public interface KASessionRepo extends CrudRepo<KASession> {
    @Modify("UPDATE KA_SESSION T " +
            "SET LAST_ACTIVE_TIME = :lastActiveTime " +
            "WHERE ID = :id")
    void updateLastActiveTime(String id, Date lastActiveTime);

    @Modify("DELETE FROM KA_SESSION WHERE NODE_ID = :nodeId")
    int deleteByNodeId(String nodeId);
}
