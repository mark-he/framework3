package com.eagletsoft.framework.keepalive.config;

import com.eagletsoft.framework.keepalive.KeepAliveServerRuntime;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KeepAliveConfig {
    @Bean
    public KeepAliveServerRuntime keepAliveServerRuntime() {
        return new KeepAliveServerRuntime();
    }
}
