package com.eagletsoft.framework.keepalive.data;

import java.util.Comparator;
import java.util.Date;

public class KAVote {
    private String nodeId;
    private Date createdTime;
    private Date lastActiveTime;
    private String role;

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getLastActiveTime() {
        return lastActiveTime;
    }

    public void setLastActiveTime(Date lastActiveTime) {
        this.lastActiveTime = lastActiveTime;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public static class VoteComparator implements Comparator<KAVote> {
        @Override
        public int compare(KAVote o1, KAVote o2) {
            return o1.createdTime.compareTo(o2.createdTime);
        }
    }
}
