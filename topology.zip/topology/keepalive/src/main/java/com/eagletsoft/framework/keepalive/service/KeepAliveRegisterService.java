package com.eagletsoft.framework.keepalive.service;

public interface KeepAliveRegisterService {
    void determineLeaderNode();
    void invalidateNode();
}
