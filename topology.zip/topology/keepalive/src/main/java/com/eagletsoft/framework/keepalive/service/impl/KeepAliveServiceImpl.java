package com.eagletsoft.framework.keepalive.service.impl;

import com.eagletsoft.framework.keepalive.KeepAliveServerRuntime;
import com.eagletsoft.framework.keepalive.data.KAVote;
import com.eagletsoft.framework.keepalive.data.entity.KARegister;
import com.eagletsoft.framework.keepalive.data.entity.KASession;
import com.eagletsoft.framework.keepalive.export.KeepAliveExportService;
import com.eagletsoft.framework.keepalive.export.stub.KeepAliveStub;
import com.eagletsoft.framework.keepalive.export.stub.NodeStub;
import com.eagletsoft.framework.keepalive.export.stub.SessionStub;
import com.eagletsoft.framework.keepalive.repo.KARegisterRepo;
import com.eagletsoft.framework.keepalive.repo.KASessionRepo;
import com.eagletsoft.framework.keepalive.service.KeepAliveRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class KeepAliveServiceImpl implements KeepAliveExportService, KeepAliveRegisterService {
    @Autowired
    private KARegisterRepo registerRepo;
    @Autowired
    private KASessionRepo sessionRepo;
    @Autowired
    private KeepAliveServerRuntime runtime;

    @Override
    public SessionStub login(String type, String nodeId) {
        sessionRepo.deleteByNodeId(nodeId);

        KASession kaSession = new KASession();
        kaSession.setType(type);
        kaSession.setNodeId(nodeId);
        sessionRepo.create(kaSession);

        registerRepo.deleteById(nodeId);
        KARegister register = new KARegister();
        register.setNodeId(nodeId);
        register.setType(type);
        register.setSessionId(kaSession.getId());
        registerRepo.create(register);

        SessionStub stub = new SessionStub();
        stub.setCreatedTime(kaSession.getCreatedTime());
        stub.setSessionId(kaSession.getId());
        stub.setKeepAliveTimeout(runtime.getKeepAliveTimeout());
        return stub;
    }

    @Override
    public void logout(String nodeId) {
        KARegister register = registerRepo.findById(nodeId);
        if (null != register) {
            register.setStatus(KARegister.StatusEnum.LOGOUT.value);
            register.setRole(KARegister.RoleEnum.INVALID.value);
            registerRepo.update(register);
        }
    }

    @Override
    public KeepAliveStub keepAlive(String nodeId, String sessionId) {
        String role = KARegister.RoleEnum.INVALID.value;
        Date lastActiveTime = new Date();
        KASession session = sessionRepo.findById(sessionId);
        if (null != session && nodeId.equals(session.getNodeId())) {
            KARegister register = registerRepo.findById(nodeId);
            if (null != register && register.getStatus().equals(KARegister.StatusEnum.ACTIVE.value)) {
                role = register.getRole();
                long timeout = runtime.getKeepAliveTimeout();
                if (lastActiveTime.getTime() - session.getLastActiveTime().getTime() < timeout) {
                    sessionRepo.updateLastActiveTime(sessionId, lastActiveTime);
                }
            }
        }
        KeepAliveStub stub = new KeepAliveStub();
        stub.setStatus(role);
        stub.setLastActiveTime(lastActiveTime);
        return stub;
    }

    @Override
    public NodeStub getAliveNodes(String type) {
        StringBuilder typePack = new StringBuilder().append("%").append(type).append("%");
        List<String> nodes = registerRepo.findActiveNodes(typePack.toString());
        NodeStub stub = new NodeStub();
        stub.getNodes().addAll(nodes);
        return stub;
    }

    @Override
    public void determineLeaderNode() {
        List<KAVote> votes = registerRepo.findActiveVotes();
        if (!votes.isEmpty()) {
            Collections.sort(votes, new KAVote.VoteComparator());
            KAVote vote = votes.get(0);
            if (!vote.getRole().equals(KARegister.RoleEnum.LEAD.value)) {
                registerRepo.clearVoteLeadExcept(vote.getNodeId());
                registerRepo.setVoteLead(vote.getNodeId());
            }
        }
    }

    @Override
    public void invalidateNode() {

    }
}
