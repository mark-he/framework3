package com.eagletsoft.framework.keepalive.repo;

import com.eagletsoft.framework.keepalive.data.KAVote;
import com.eagletsoft.framework.keepalive.data.entity.KARegister;
import com.eagletsoft.framework.orm.repo.exec.CrudRepo;
import com.eagletsoft.framework.orm.repo.exec.meta.Modify;
import com.eagletsoft.framework.orm.repo.exec.meta.Query;
import com.eagletsoft.framework.orm.repo.meta.Repo;

import java.util.Date;
import java.util.List;

@Repo(enetityClass = KARegister.class)
public interface KARegisterRepo extends CrudRepo<KARegister> {

    @Query("SELECT T.NODE_ID, " +
            "T.CREATED_TIME, " +
            "T.ROLE FROM KA_REGISTER T " +
            "LEFT JOIN KA_SESSION T2 ON T2.ID = T.SESSION_ID " +
            "WHERE T.STATUS = 'ACTIVE'")
    List<KAVote> findActiveVotes();

    @Query("SELECT T.NODE_ID " +
            "FROM KA_REGISTER T " +
            "LEFT JOIN KA_SESSION T2 ON T2.ID = T.SESSION_ID " +
            "WHERE T.STATUS = 'ACTIVE' AND T.TYPE LIKE :typePack")
    List<String> findActiveNodes(String typePack);

    @Modify("UPDATE KA_REGISTER T " +
            "SET ROLE = 'FOLLOW' " +
            "WHERE NODE_ID <> :nodeId AND " +
            "STATUS = 'ACTIVE'")
    void clearVoteLeadExcept(String nodeId);

    @Modify("UPDATE KA_REGISTER T " +
            "SET ROLE = 'LEAD' " +
            "WHERE NODE_ID = :nodeId AND STATUS = 'ACTIVE'")
    void setVoteLead(String nodeId);

    @Modify("UPDATE KA_REGISTER T " +
            "SET STATUS = 'INACTIVE', ROLE = 'INVALID' " +
            "WHERE STATUS = 'ACTIVE' AND (EXISTS( " +
            "SELECT 1 FROM KA_SESSION T2 " +
            "WHERE T2.ID = T.SESSION_ID AND T2.LAST_ACTIVE_TIME < :lastActiveTime " +
            "))")
    int invalidateNode(Date lastActiveTime);
}
