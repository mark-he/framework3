package com.eagletsoft.framework.topology.engine;

import com.eagletsoft.framework.topology.common.SpecException;
import com.eagletsoft.framework.topology.engine.job.Kettle;
import com.eagletsoft.framework.topology.engine.job.KettleGroup;
import com.eagletsoft.framework.topology.engine.keepalive.KeepAliveConnector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.net.InetAddress;

@Component
public class DefaultEngine implements Engine {
    @Autowired
    private EngineRuntime runtime;
    @Autowired
    private KeepAliveConnector connector;
    @Autowired
    private KettleGroup kettleGroup;

    @PostConstruct
    protected void init() {
        try {
            String nodeId = System.getProperty("node.id", InetAddress.getLocalHost().getHostAddress());
            String nodeType = System.getProperty("node.type", "WORKER");
            runtime.setNodeId(nodeId);
            runtime.setNodeType(nodeType);
        } catch (Exception ex) {
            throw new SpecException(ex);
        }
    }

    @Override
    public void start() {
        init();
        connector.connect();
        kettleGroup.start();
    }

    @Override
    public void shutdown() {
        kettleGroup.stop();
        connector.disconnect();
    }

    @Override
    public void submit(Kettle kettle) {
        kettleGroup.addKettle(kettle);
    }
}
