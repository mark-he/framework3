package com.eagletsoft.framework.topology.engine.job;

import java.util.HashMap;
import java.util.Map;

public class Switcher extends Teapot implements Router {
    private Map<String, Teapot> routes = new HashMap<>();

    public Switcher(String name) {
        super(name);
        this.setSpout((traceId, event, workspace, teapot) -> {
            Teapot target = null;
            for (Map.Entry<String, Teapot> entry : routes.entrySet()) {
                if (entry.getKey().equals(event.getType())) {
                    target = entry.getValue();
                }
            }
            workspace.runTeapot(traceId, event, target);
        });
    }

    public Switcher add(String eventType, Teapot teapot) {
        routes.put(eventType, teapot);
        return this;
    }

    @Override
    public Teapot[] getSubsequence() {
        return routes.values().toArray(new Teapot[0]);
    }
}
