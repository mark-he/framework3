package com.eagletsoft.framework.topology.engine.job;

public interface Kettle {
    boolean isLead();
    String getName();
    Teapot getTeapot();
    Teapot setTeapot(Teapot root);
    Teapot setTeapot(String name, Spout spout, int parallelism);
    boolean loop(Workspace workspace);
    default void fail(Event event, Throwable throwable) {
        System.out.println("fail: " + event.getId());
        throwable.printStackTrace();
    }

    default void success(Event event, Object... result) {
        System.out.println("success: " + event.getId());
    }
}
