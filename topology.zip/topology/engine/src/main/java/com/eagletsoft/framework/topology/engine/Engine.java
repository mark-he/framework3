package com.eagletsoft.framework.topology.engine;

import com.eagletsoft.framework.topology.engine.job.Kettle;

public interface Engine {
    void start();
    void shutdown();
    void submit(Kettle kettle);
}
