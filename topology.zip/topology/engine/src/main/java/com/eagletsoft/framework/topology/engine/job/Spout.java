package com.eagletsoft.framework.topology.engine.job;

public interface Spout {
    void run(String traceId, Event event, Workspace workspace, Teapot teapot);
}
