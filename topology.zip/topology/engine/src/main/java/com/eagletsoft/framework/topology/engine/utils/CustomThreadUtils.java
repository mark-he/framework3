package com.eagletsoft.framework.topology.engine.utils;

import java.util.concurrent.*;

public class CustomThreadUtils {
    public static void sleep(long duration) {
        try {
            Thread.sleep(duration);
        } catch (Exception ex) {}
    }

    public static ScheduledThreadPoolExecutor createScheduledExecutor(int core) {
        return new ScheduledThreadPoolExecutor(core, Executors.defaultThreadFactory());
    }

    public static ThreadPoolExecutor createFixedThreadExecutor(int nThreads, int queueSize) {
        return new ThreadPoolExecutor(nThreads, nThreads, 0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(queueSize), Executors.defaultThreadFactory());
    }

    public static Thread run(String name, Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setName(name);
        thread.start();
        return thread;
    }

    public static ThreadPoolExecutor createThreadExecutor(int core, int max, int queueSize) {
        return new ThreadPoolExecutor(core, max, 0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(queueSize), Executors.defaultThreadFactory());
    }
}
