package com.eagletsoft.framework.topology.engine.job;

import java.util.UUID;

public class Event {
    private String id;
    private String type;
    private Object[] data;
    private Object[] result;

    public Event(String type, Object... data) {
        this.id = UUID.randomUUID().toString();
        this.type = type;
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Object[] getData() {
        return data;
    }

    public void setData(Object[] data) {
        this.data = data;
    }

    public Object[] getResult() {
        return result;
    }

    public void setResult(Object[] result) {
        this.result = result;
    }
}
