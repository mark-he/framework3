package com.eagletsoft.framework.topology.engine.job;

public abstract class BasicKettle implements Kettle {
    private Teapot teapot;
    private boolean isLead;
    private String name;

    public BasicKettle(String name) {
        this.name = name;
    }

    @Override
    public boolean isLead() {
        return this.isLead;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Teapot getTeapot() {
        return this.teapot;
    }

    @Override
    public Teapot setTeapot(Teapot root) {
        this.teapot = root;
        return root;
    }

    @Override
    public Teapot setTeapot(String name, Spout spout, int parallelism) {
        return setTeapot(new Teapot(name, spout, parallelism));
    }
}
