package com.eagletsoft.framework.topology.engine;

import com.eagletsoft.framework.keepalive.export.stub.SessionStub;

import javax.management.relation.Role;
import java.util.concurrent.TimeUnit;

public class EngineRuntime {
    private String nodeId;
    private String role = RoleEnum.INVALID.value;
    private String nodeType = "WORKER";
    private long keepAliveDelay = 1000L;
    private long keepAliveInterval = 3000L;
    private int maximumPendingEvent = 500;
    private TimeUnit unit = TimeUnit.MILLISECONDS;
    private SessionStub session;

    public boolean isRunning() {
        return null != session;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getNodeType() {
        return nodeType;
    }

    public void setNodeType(String nodeType) {
        this.nodeType = nodeType;
    }

    public long getKeepAliveDelay() {
        return keepAliveDelay;
    }

    public void setKeepAliveDelay(long keepAliveDelay) {
        this.keepAliveDelay = keepAliveDelay;
    }

    public long getKeepAliveInterval() {
        return keepAliveInterval;
    }

    public void setKeepAliveInterval(long keepAliveInterval) {
        this.keepAliveInterval = keepAliveInterval;
    }

    public int getMaximumPendingEvent() {
        return maximumPendingEvent;
    }

    public void setMaximumPendingEvent(int maximumPendingEvent) {
        this.maximumPendingEvent = maximumPendingEvent;
    }

    public TimeUnit getUnit() {
        return unit;
    }

    public void setUnit(TimeUnit unit) {
        this.unit = unit;
    }

    public SessionStub getSession() {
        return session;
    }

    public void setSession(SessionStub session) {
        this.session = session;
    }

    public enum RoleEnum {
        LEAD("LEAD"),
        FOLLOW("FOLLOW"),
        INVALID("INVALID");
        public String value;

        RoleEnum(String value) {
            this.value = value;
        }
    }
}
