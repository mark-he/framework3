package com.eagletsoft.framework.topology.engine.keepalive;

import com.eagletsoft.framework.keepalive.export.KeepAliveExportService;
import com.eagletsoft.framework.keepalive.export.stub.KeepAliveStub;
import com.eagletsoft.framework.keepalive.export.stub.NodeStub;
import com.eagletsoft.framework.keepalive.export.stub.SessionStub;
import com.eagletsoft.framework.topology.common.Environment;
import com.eagletsoft.framework.topology.engine.EngineRuntime;
import com.eagletsoft.framework.topology.engine.utils.CustomThreadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;

@Component
public class KeepAliveConnector {
    @Autowired
    private KeepAliveExportService keepAliveExportService;
    @Autowired
    private EngineRuntime runtime;
    private ScheduledExecutorService keepalive;

    public synchronized void connect() {
        keepalive = CustomThreadUtils.createScheduledExecutor(1);

        SessionStub newSession = keepAliveExportService.login(runtime.getNodeType(), runtime.getNodeId());
        if (!StringUtils.isEmpty(newSession.getSessionId())) {
            Environment.getInstance().getLogger().warn("Engine connected");
            runtime.setSession(newSession);

            keepalive.scheduleAtFixedRate(() -> {
                try {
                    if (runtime.isRunning()) {
                        KeepAliveStub stub = keepAliveExportService.keepAlive(runtime.getNodeId(), runtime.getSession().getSessionId());
                        runtime.setRole(stub.getStatus());
                        if (EngineRuntime.RoleEnum.INVALID.value.equals(stub.getStatus())) {
                            Environment.getInstance().getLogger().warn("Engine connection was broken.");
                            reconnect();
                        }
                    }
                } catch (Exception ex) {
                    Environment.getInstance().getLogger().error("KeepAlive error.", ex);
                }
            }, runtime.getKeepAliveDelay(), runtime.getKeepAliveInterval(), runtime.getUnit());
        }
    }

    private synchronized void reconnect() {
        runtime.setSession(null);
        keepalive.shutdown();
        connect();
    }

    public synchronized void disconnect() {
        if (runtime.isRunning()) {
            keepAliveExportService.logout(runtime.getNodeId());
            runtime.setSession(null);
        }
        keepalive.shutdown();
    }

    public List<String> getAliveNodes(String type) {
        NodeStub stub = keepAliveExportService.getAliveNodes(type);
        return Collections.unmodifiableList(stub.getNodes());
    }
}
