package com.eagletsoft.framework.topology.engine.job;

import com.eagletsoft.framework.topology.engine.EngineRuntime;
import com.eagletsoft.framework.topology.engine.utils.CustomThreadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class KettleGroup {
    @Autowired
    private EngineRuntime runtime;
    private List<Workspace> workspaces = new ArrayList<>();
    private Map<String, Thread> threadMap = new ConcurrentHashMap<>();

    public void addKettle(Kettle kettle) {
        Workspace workspace = new Workspace(runtime, kettle);
        workspaces.add(workspace);

        Thread threa = CustomThreadUtils.run(kettle.getName(), () -> {
            workspace.start();
        });
        threadMap.put(kettle.getName(), threa);
    }

    public void start() {

    }

    public void stop() {
        for (Workspace workspace : workspaces) {
            workspace.stop();
        }
    }
}
