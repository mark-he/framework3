package com.eagletsoft.framework.topology.engine.job;

import com.eagletsoft.framework.topology.common.Environment;
import com.eagletsoft.framework.topology.engine.EngineRuntime;
import com.eagletsoft.framework.topology.engine.utils.CustomThreadUtils;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

public class Workspace {
    private Kettle kettle;
    private EngineRuntime runtime;
    private boolean running;

    private Map<String, Executor> executorMap = new ConcurrentHashMap<>();
    private Map<String, Event> eventMap = new ConcurrentHashMap<>();
    private Map<String, AtomicInteger> eventStatus = new ConcurrentHashMap<>();

    public Workspace(EngineRuntime runtime, Kettle kettle) {
        this.kettle = kettle;
        this.runtime = runtime;
    }

    public Kettle getKettle() {
        return kettle;
    }

    public EngineRuntime getRuntime() {
        return runtime;
    }

    public boolean start() {
        running = true;
        boolean isLoop = true;
        this.compileJob();
        while(running && isLoop) {
            if (runtime.isRunning()) {
                if (eventMap.size() >= runtime.getMaximumPendingEvent()) {
                    takeBreak(1);
                }
                if (kettle.isLead()) {
                    boolean lead = EngineRuntime.RoleEnum.LEAD.value.equals(runtime.getRole());
                    if (lead) {
                        isLoop = runKettle();
                    } else {
                        takeBreak(1);
                    }
                } else {
                    boolean invalid = EngineRuntime.RoleEnum.INVALID.value.equals(runtime.getRole());
                    if (invalid) {
                        takeBreak(1);
                    } else {
                        isLoop = runKettle();
                    }
                }
            } else {
                takeBreak(1);
            }
        }
        return true;
    }

    private void takeBreak(int seconds) {
        CustomThreadUtils.sleep(seconds * 1000);
    }

    private boolean runKettle() {
        try {
            return kettle.loop(this);
        } catch (Exception ex) {
            Environment.getInstance().getLogger().error("Error in runKettle.", ex);
            takeBreak(10);
            return true;
        }
    }

    public void stop() {
        running = false;
    }

    private void compileJob() {
        prepare(kettle.getTeapot());
    }

    private void prepare(Teapot teapot) {
        if (teapot instanceof Router) {
            for (Teapot act : ((Router)teapot).getSubsequence()) {
                prepare(act);
            }
        } else {
            ExecutorService pool = CustomThreadUtils.createThreadExecutor(teapot.parallelism, teapot.parallelism * 2, 1000);
            executorMap.put(teapot.getName(), pool);
            if (null != teapot.nextTeapot) {
                prepare(teapot.nextTeapot);
            }
        }
    }

    public void emit(Event event, Kettle kettle) {
        String traceId = UUID.randomUUID().toString();
        eventMap.put(traceId, event);
        eventStatus.put(traceId, new AtomicInteger(1));
        this.runTeapot(traceId, event, kettle.getTeapot());
    }

    public void emit(String traceId, Event event, Teapot teapot) {
        if (null != teapot.nextTeapot) {
            AtomicInteger counter = eventStatus.get(traceId);
            if (null != counter) {
                counter.incrementAndGet();
            }
            this.runTeapot(traceId, event, teapot.nextTeapot);
        }
    }

    public void runTeapot(String traceId, Event event, Teapot teapot) {
        if (Router.class.isAssignableFrom(teapot.getClass())) {
            teapot.spout.run(traceId, event, this, teapot);
        } else {
            Executor executor = executorMap.get(teapot.getName());
            executor.execute(() -> {
                Event sourceEvent = eventMap.get(traceId);
                try {
                    teapot.spout.run(traceId, event, Workspace.this, teapot);

                    AtomicInteger counter = eventStatus.get(traceId);
                    if (null != counter) {
                        if (0 == counter.decrementAndGet()) {
                            eventMap.remove(traceId);
                            eventStatus.remove(traceId);
                            kettle.success(sourceEvent, event.getResult());
                        }
                    }
                } catch (Exception ex) {
                    eventMap.remove(traceId);
                    eventStatus.remove(traceId);
                    Environment.getInstance().getLogger().error("Error in runTeapot.", ex);

                    try {
                        kettle.fail(sourceEvent, ex);
                    } catch (Exception ex2) {
                        Environment.getInstance().getLogger().error("Error in runTeapot.", ex2);
                    }
                }
            });
        }
    }
}
