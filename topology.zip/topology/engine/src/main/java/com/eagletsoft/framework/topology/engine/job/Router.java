package com.eagletsoft.framework.topology.engine.job;

public interface Router {
    Teapot[] getSubsequence();
}
