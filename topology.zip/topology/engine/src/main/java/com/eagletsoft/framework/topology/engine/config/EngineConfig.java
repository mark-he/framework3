package com.eagletsoft.framework.topology.engine.config;

import com.eagletsoft.framework.topology.engine.EngineRuntime;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EngineConfig {
    @Bean
    public EngineRuntime engineRuntime() {
        return new EngineRuntime();
    }
}
