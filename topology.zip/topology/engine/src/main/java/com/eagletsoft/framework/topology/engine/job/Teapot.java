package com.eagletsoft.framework.topology.engine.job;

public class Teapot {
    protected String name;
    protected Spout spout;
    protected int parallelism = 1;
    protected Teapot nextTeapot;

    public Teapot(String name, Spout spout, int parallelism) {
        this.name = name;
        this.spout = spout;
        this.parallelism = parallelism;
    }

    public Teapot transmit(Teapot teapot) {
        this.nextTeapot = teapot;
        return teapot;
    }

    public Teapot transmit(String name, Spout spout, int parallelism) {
        return this.transmit(new Teapot(name, spout, parallelism));
    }

    public Teapot(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Spout getSpout() {
        return spout;
    }

    public void setSpout(Spout spout) {
        this.spout = spout;
    }

    public int getParallelism() {
        return parallelism;
    }

    public void setParallelism(int parallelism) {
        this.parallelism = parallelism;
    }
}
