package com.eagletsoft.framework.orm.entity.inject;

import com.eagletsoft.framework.orm.entity.inject.meta.EntityInject;
import com.eagletsoft.framework.orm.entity.inject.meta.Operations;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.annotation.Annotation;

public class InjectHelper {

    private InjectHelper() {

    }

    public static void inject(Object obj) {
        inject(obj, Operations.CREATE);
    }

    public static void inject(Object obj, int operation) {
        if (null != obj) {
            ReflectionUtils.doWithFields(obj.getClass(), f -> {
                try {
                    Annotation[] anns = f.getAnnotations();
                    for (Annotation ann : anns) {
                        EntityInject daoInject = AnnotationUtils.getAnnotation(ann, EntityInject.class);
                        if (null != daoInject) {
                            Integer operationValue = (Integer) AnnotationUtils.getValue(ann, "operation");
                            if (null != operationValue && (operation & operationValue) > 0) {
                                EntityInjector<Annotation, Object> daoInjector = daoInject.injectedBy().newInstance();
                                ReflectionUtils.makeAccessible(f);
                                Object fieldObj = ReflectionUtils.getField(f, obj);
                                Object value = daoInjector.getInjectValue(ann, f.getType(), fieldObj);
                                if (value != fieldObj) {
                                    ReflectionUtils.setField(f, obj, value);
                                }
                            }
                        }
                    }
                } catch (Throwable t) {
                    throw new RuntimeException(t);
                }
            });
        }
    }
}
