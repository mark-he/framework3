package com.eagletsoft.framework.orm.assemble;

import java.util.LinkedList;
import java.util.List;

public interface PropertyAssembler {
    default Object assemble(Object[] vars) {
        return null;
    }

    default List<BatchResult> assemble(List<Object[]> varList) {
        List<BatchResult> rets = new LinkedList<>();
        for (Object[] vars : varList) {
            rets.add(new BatchResult(vars, assemble(vars)));
        }
        return rets;
    }

    default boolean isPreferredBatch() {
        return false;
    }
    class BatchResult {
        Object[] vars;
        Object result;

        public BatchResult(Object[] vars, Object result) {
            this.vars = vars;
            this.result = result;
        }

        public Object[] getVars() {
            return vars;
        }

        public void setVars(Object[] vars) {
            this.vars = vars;
        }

        public Object getResult() {
            return result;
        }

        public void setResult(Object result) {
            this.result = result;
        }
    }
}
