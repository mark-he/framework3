package com.eagletsoft.framework.orm.repo.jdbc;

import java.util.HashMap;
import java.util.Map;

public class JdbcHelperFactory {
    private static JdbcHelperFactory INSTANCE = new JdbcHelperFactory();
    private Map<String, JdbcHelper> helperMap = new HashMap<>();

    public static JdbcHelperFactory getInstance() {
        return INSTANCE;
    }

    public JdbcHelper create(String profile) {
        return helperMap.get(normalizeProfile(profile));
    }

    private String normalizeProfile(String profile) {
        if (null == profile) {
            profile = "";
        } else {
            profile = profile.trim().toUpperCase();
        }
        return profile;
    }
}
