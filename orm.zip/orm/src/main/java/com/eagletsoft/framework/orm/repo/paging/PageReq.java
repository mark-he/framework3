package com.eagletsoft.framework.orm.repo.paging;

public class PageReq {
    private int index;
    private int size = 10;

    public PageReq(int index, int size) {
        this.index = index;
        this.size = size;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
