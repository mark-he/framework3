package com.eagletsoft.framework.orm.repo.naming;

public class NamingUtils {
    private NamingUtils() {}

    public static String convertCamelToSnake(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                sb.append('_');
            }
            sb.append(c);
        }
        return sb.toString().toUpperCase();
    }

    public static String convertSnakeToCamel(String str) {
        StringBuilder sb = new StringBuilder();
        boolean matched = false;
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if ('_' == c) {
                matched = true;
            } else {
                if (matched) {
                    sb.append(String.valueOf(c).toUpperCase());
                } else {
                    sb.append(String.valueOf(c).toLowerCase());
                }
                matched = false;
            }
        }
        return sb.toString();
    }
}
