package com.eagletsoft.framework.orm.repo.jdbc;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import java.util.Map;

public class EnhanceMapParameterSource extends MapSqlParameterSource {
    public EnhanceMapParameterSource(Map<String, ?> values) {
        super(values);
    }

    @Override
    public boolean hasValue(String paramName) {
        if (paramName.indexOf('.') > -1) {
            String[] names = paramName.split("\\.", -1);
            Object obj = this.getValues().get(names[0]);
            if (null != obj) {
                try {
                    Object value = PropertyUtils.getProperty(obj, names[1]);
                } catch (Exception ex) {
                }
            }
            return false;
        } else {
            return super.hasValue(paramName);
        }
    }

    @Override
    public Object getValue(String paramName) {
        if (paramName.indexOf('.') > -1) {
            String[] names = paramName.split("\\.", -1);
            Object obj = this.getValues().get(names[0]);
            try {
                return PropertyUtils.getProperty(obj, names[1]);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        } else {
            return super.getValue(paramName);
        }
    }
}
