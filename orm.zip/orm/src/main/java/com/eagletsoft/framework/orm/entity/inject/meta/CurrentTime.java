package com.eagletsoft.framework.orm.entity.inject.meta;

import com.eagletsoft.framework.orm.entity.inject.impl.CurrentTimeInjector;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@EntityInject(injectedBy = CurrentTimeInjector.class)
public @interface CurrentTime {
    String format() default "yyyy-MM-dd HH:mm:ss";
    int operation() default Operations.CREATE;
}
