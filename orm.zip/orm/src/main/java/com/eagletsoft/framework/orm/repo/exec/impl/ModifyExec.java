package com.eagletsoft.framework.orm.repo.exec.impl;

import com.eagletsoft.framework.orm.mapper.MapperLoader;
import com.eagletsoft.framework.orm.repo.jdbc.JdbcHelperFactory;
import org.springframework.util.StringUtils;

import java.lang.reflect.Method;
import java.util.Map;

public class ModifyExec extends RepoExecAnnotationService {
    @Override
    public Object process(Method method, Object[] args) {
        String sql = (String)annConfig.get("value");
        if (StringUtils.isEmpty(sql)) {
            sql = MapperLoader.getInstance().getSql(method.getDeclaringClass().getName(), method.getName());
        }
        Map<String, Object> parameters = getMethodParameters(method, args);
        return JdbcHelperFactory.getInstance().create(profile).update(sql, parameters);
    }
}
