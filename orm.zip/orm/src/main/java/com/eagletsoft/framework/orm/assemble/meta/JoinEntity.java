package com.eagletsoft.framework.orm.assemble.meta;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface JoinEntity {
    String tableName();
}
