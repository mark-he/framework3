package com.eagletsoft.framework.orm.utils;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.MergedAnnotations;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BeanUtils {

    public static Map<String, Object> getMethodParam(ProceedingJoinPoint point) {
        MethodSignature signature = (MethodSignature) point.getSignature();

        Map<String, Object> parameters = new HashMap<>();
        String[] names = signature.getParameterNames();

        for (int i = 0; i < names.length; i++) {
            Object param = point.getArgs()[i];
            parameters.put(names[i], param);
        }
        return parameters;
    }

    public static Map<String, Field> getFieldMap(Class clazz) {
        Map<String, Field> ret = new HashMap<>();
        ReflectionUtils.doWithFields(clazz, f -> ret.put(f.getName(), f));
        return ret;
    }

    public static List<Annotation> getAnnotations(AnnotatedElement e) {
        List<Annotation> ret = new ArrayList<>();
        MergedAnnotations.from(e).forEach(x -> {
            if (x.isDirectlyPresent()) {
                ret.add(x.getRoot().synthesize());
            }
        });
        return ret;
    }

    public static <A> List<A> findInheritAnnotationsByType(Class clazz, Class<A> annotationType) {
        List<A> annotations = new ArrayList<>();
        Annotation[] ann = clazz.getAnnotationsByType(annotationType);
        annotations.addAll(CollectionUtils.arrayToList(ann));

        if (!clazz.getSuperclass().getCanonicalName().equals(Object.class.getCanonicalName())) {
            annotations.addAll(findInheritAnnotationsByType(clazz.getSuperclass(), annotationType));
        }
        return annotations;
    }
}
