package com.eagletsoft.framework.orm.assemble.join.dao.meta;

public @interface ValuePredicate {
    String key();
    String op() default "=";
    String value();
}
