package com.eagletsoft.framework.orm.assemble.join;

import com.eagletsoft.framework.orm.assemble.AssembleLoader;
import com.eagletsoft.framework.orm.assemble.BeanAssemblerHelper;
import com.eagletsoft.framework.orm.assemble.join.dao.Entry;
import com.eagletsoft.framework.orm.assemble.join.dao.JoinQueryDao;
import com.eagletsoft.framework.orm.assemble.join.meta.AssembleJoin;
import ognl.Ognl;
import ognl.OgnlException;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.*;

public class AssembleJoinLoader implements AssembleLoader<AssembleJoin>, BeanAssemblerHelper.Context.Listener {
    private Map<String, List<Job>> jobMap = new HashMap<>();

    @Override
    public void load(Object root, Field f, AssembleJoin ann) {
        try {
            Job job = new Job(root, f, ann);
            String key = f.getName();
            List<Job> jobs = jobMap.computeIfAbsent(key, k -> {
               List<Job> j = new LinkedList<>();
               jobMap.put(k, j);
               return j;
            });
            jobs.add(job);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void onEndLoad(BeanAssemblerHelper.Context ctx) {
        try {
            processJobMap();
        } catch (Throwable ex) {
            throw new RuntimeException(ex);
        }
    }

    private void processJobMap() throws Throwable {
        for (Map.Entry<String, List<Job>> entry : jobMap.entrySet()) {
            processFieldJob(entry.getValue());
        }
    }

    private void processFieldJob(List<Job> jobs) throws Throwable {
        if (jobs.size() > 0) {
            Job template = jobs.get(0);
            AssembleJoin assembleJoin = template.ann;
            Field f = FieldUtils.getField(template.bean.getClass(), assembleJoin.onValueField(), true);
            Class keyType = f.getType();
            Class viewType = getViewType(template.field);

            Set<Object> onValues = new HashSet<>();
            jobs.stream().forEach(job -> {
                if (null != job.onValueParam) {
                    onValues.add(job.onValueParam);
                }
            });

            JoinQueryDao queryDao = FrameworkUtils.getBean(JoinQueryDao.class);
            List<Entry> list = queryDao.getJoinData(assembleJoin, onValues, keyType, viewType);

            for (Job job : jobs) {
                if (null != job.onValueParam) {
                    if (Collection.class.isAssignableFrom(job.field.getType())) {
                        Collection col = createDefaultCollection(job.field.getType());
                        ReflectionUtils.setField(job.field, job.bean, col);
                        for (Entry entry : list) {
                            if (entry.getKey().equals(job.onValueParam)) {
                                col.add(entry.getValue());
                            }
                        }
                    } else {
                        for (Entry entry : list) {
                            if (entry.getKey().equals(job.onValueParam)) {
                                ReflectionUtils.setField(job.field, job.bean, entry.getValue());
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    private Class getViewType(Field field) {
        if (Collection.class.isAssignableFrom(field.getType())) {
            return (Class)((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
        } else {
            return field.getType();
        }
    }

    private Collection createDefaultCollection(Class clazz) throws InstantiationException, IllegalAccessException {
        if (!clazz.isInterface()) {
            return (Collection) clazz.newInstance();
        }
        if (clazz.isAssignableFrom(List.class)) {
            return new ArrayList();
        } else if (clazz.isAssignableFrom(Set.class)) {
            return new HashSet();
        } else {
            throw new RuntimeException("Please provide a specific type for assemble join.");
        }
    }

    private static class Job {
        Object bean;
        Field field;
        AssembleJoin ann;
        Object onValueParam;

        public Job(Object bean, Field field, AssembleJoin ann) throws OgnlException {
            this.bean = bean;
            this.field = field;
            this.ann = ann;
            onValueParam = getParamValues(bean, ann.onValueField());
        }

        private Object getParamValues(Object ret, String value) throws OgnlException {
            if (!StringUtils.isEmpty(value)) {
                return Ognl.getValue(value, ret);
            }
            return null;
        }
    }
}
