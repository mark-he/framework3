package com.eagletsoft.framework.orm.entity.inject.impl;

import com.eagletsoft.framework.orm.entity.inject.EntityInjector;
import com.eagletsoft.framework.orm.entity.inject.meta.Trunc;
import org.springframework.util.StringUtils;

public class TruncInjector implements EntityInjector<Trunc, String> {
    @Override
    public String getInjectValue(Trunc annotation, Class type, String value) {
        if (!StringUtils.isEmpty(value)) {
            if (value.length() > annotation.value()) {
                value = value.substring(0, annotation.value());
            }
        }
        return value;
    }
}
