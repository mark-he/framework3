package com.eagletsoft.framework.orm.assemble.join.meta;

import com.eagletsoft.framework.orm.assemble.join.AssembleJoinLoader;
import com.eagletsoft.framework.orm.assemble.join.dao.meta.ValuePredicate;
import com.eagletsoft.framework.orm.assemble.meta.Loader;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@Loader(loadedBy = AssembleJoinLoader.class)
public @interface AssembleJoin {
    Class<?> entityType();
    String onEntityField();
    String onValueField();
    String singleProp() default "";
    ValuePredicate[] where() default {};
    String orderBy() default "";
    int limit() default -1;
}
