package com.eagletsoft.framework.orm.assemble;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

public interface AssembleLoader<T extends Annotation> {
    void load(Object root, Field f, T ann);
}
