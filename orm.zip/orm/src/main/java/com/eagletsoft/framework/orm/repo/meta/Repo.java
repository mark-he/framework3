package com.eagletsoft.framework.orm.repo.meta;


import com.eagletsoft.framework.orm.repo.exec.RepoExecTemplate;
import com.eagletsoft.framework.orm.repo.exec.impl.CrudRepoExecTemplate;
import com.eagletsoft.framework.orm.repo.naming.NamingStrategy;
import com.eagletsoft.framework.orm.repo.naming.ReadCamelToSnakeStrategy;
import org.springframework.core.annotation.AliasFor;
import org.springframework.stereotype.Component;

import java.lang.annotation.*;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
public @interface Repo {
    @AliasFor(annotation = Component.class)
    String value() default "";
    String profile() default "";
    Class enetityClass() default Void.class;
    Class<? extends NamingStrategy> namingStrategy() default ReadCamelToSnakeStrategy.class;
    Class<? extends RepoExecTemplate> template() default CrudRepoExecTemplate.class;
}
