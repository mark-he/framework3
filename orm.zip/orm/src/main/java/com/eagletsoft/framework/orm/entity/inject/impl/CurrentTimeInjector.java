package com.eagletsoft.framework.orm.entity.inject.impl;

import com.eagletsoft.framework.orm.entity.inject.EntityInjector;
import com.eagletsoft.framework.orm.entity.inject.meta.CurrentTime;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CurrentTimeInjector implements EntityInjector<CurrentTime, Object> {
    @Override
    public Object getInjectValue(CurrentTime annotation, Class type, Object value) {
        if (Date.class.isAssignableFrom(type)) {
            value = new Date();
        } else if (String.class.isAssignableFrom(type)) {
            SimpleDateFormat sdf = new SimpleDateFormat(annotation.format());
            value = sdf.format(new Date());
        } else if (Long.class.isAssignableFrom(type)) {
            value = System.currentTimeMillis();
        }
        return value;
    }
}
