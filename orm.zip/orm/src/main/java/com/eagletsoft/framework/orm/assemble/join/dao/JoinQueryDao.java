package com.eagletsoft.framework.orm.assemble.join.dao;

import com.eagletsoft.framework.orm.assemble.join.dao.meta.ValuePredicate;
import com.eagletsoft.framework.orm.assemble.join.meta.AssembleJoin;
import com.eagletsoft.framework.orm.assemble.meta.JoinEntity;
import com.eagletsoft.framework.orm.repo.jdbc.JdbcHelperFactory;
import com.eagletsoft.framework.orm.repo.naming.NamingUtils;
import com.eagletsoft.framework.orm.utils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.util.*;

@Component
public class JoinQueryDao {
    @Autowired
    private JdbcHelperFactory jdbcHelperFactory;

    public List<Entry> getJoinData(AssembleJoin assembleJoin, Collection onValues, Class keyType, Class viewType) {
        StringBuilder sb = new StringBuilder();
        String tableName = getTableName(assembleJoin.entityType());
        String onField = NamingUtils.convertCamelToSnake(assembleJoin.onEntityField());
        String fieldNames = getFieldNames(assembleJoin, viewType);
        StringBuilder whereClause = new StringBuilder();
        whereClause.append(String.format(" WHERE %s IN (:values) ", onField));

        if (assembleJoin.where().length > 0) {
            whereClause.append(" AND ").append(buildWhere(assembleJoin.where()));
        }
        if (assembleJoin.limit() <= 0) {
            sb.append(String.format("SELECT %s FROM %s T %s", fieldNames, tableName, whereClause));
            if (!StringUtils.isEmpty(assembleJoin.orderBy())) {
                sb.append(" ORDER BY ").append(getOrderBy(assembleJoin));
            }
        } else {
            if (StringUtils.isEmpty(assembleJoin.orderBy())) {
                throw new RuntimeException("Missed orderBy parameter when limit was provided.");
            }
            sb.append(String.format("SELECT * FROM (SELECT %s, ROW_NUMBER() OVER(PARTITION BY %s ORDER BY %s) RN" +
                    " FROM %s T %s) WHERE RN <= %d", fieldNames, onField, getOrderBy(assembleJoin), tableName, whereClause, assembleJoin.limit()));
        }
        Map<String, Object> params = new HashMap<>();
        params.put("values", onValues);

        if (!StringUtils.isEmpty(assembleJoin.singleProp())) {
            List<Entry> ret = jdbcHelperFactory.create("").query(sb.toString(), params, getEntryBeanPropertyRowMapper(assembleJoin, keyType, viewType));
            return ret;
        } else {
            List<Entry> ret = new ArrayList<>();
            List list = jdbcHelperFactory.create("").query(sb.toString(), params, getEntryBeanPropertyRowMapper(assembleJoin, keyType, viewType));
            try {
                for (Object obj : list) {
                    Object key = PropertyUtils.getProperty(obj, assembleJoin.onEntityField());
                    ret.add(new Entry(key, obj));
                }
                return ret;
            } catch (Throwable t) {
                throw new RuntimeException(t);
            }
        }
    }

    private EntryRowMapper getEntryBeanPropertyRowMapper(AssembleJoin assembleJoin, Class keyType, Class viewType) {
        if (!StringUtils.isEmpty(assembleJoin.singleProp())) {
            Map<String, Class> modifiedType = new HashMap<>();
            modifiedType.put("key", keyType);
            modifiedType.put("value", viewType);
            return new EntryRowMapper(Entry.class, modifiedType);
        } else {
            return new EntryRowMapper(viewType, null);
        }
    }

    private String getFieldNames(AssembleJoin assembleJoin, Class viewType) {
        StringBuilder sb = new StringBuilder();
        if (!StringUtils.isEmpty(assembleJoin.singleProp())) {
            sb.append("T.").append(NamingUtils.convertCamelToSnake(assembleJoin.onEntityField())).append(" AS KEY ");
            sb.append(", ");
            sb.append("T.").append(NamingUtils.convertCamelToSnake(assembleJoin.singleProp())).append(" AS VALUE ");
        } else {
            Map<String, Field> entityFields = BeanUtils.getFieldMap(assembleJoin.entityType());
            ReflectionUtils.doWithFields(viewType, f -> {
                if (entityFields.containsKey(f.getName())) {
                    if (sb.length() > 0) {
                        sb.append(", ");
                    }
                    sb.append("T.").append(NamingUtils.convertCamelToSnake(f.getName()));
                }
            });
        }
        return sb.toString();
    }

    private String buildWhere(ValuePredicate[] vps) {
        StringBuilder sb = new StringBuilder();
        for (ValuePredicate vp : vps) {
            if (sb.length() > 0) {
                sb.append(" ").append(vp.op()).append(" ");
            }
            sb.append(buildWhere(vp));
        }
        return sb.toString();
    }

    private String getOrderBy(AssembleJoin assembleJoin) {
        return NamingUtils.convertCamelToSnake(assembleJoin.orderBy());
    }

    private String buildWhere(ValuePredicate vp) {
        StringBuilder sb = new StringBuilder();
        sb.append(NamingUtils.convertCamelToSnake(vp.key()));
        sb.append(" = ");
        sb.append(vp.value());
        return sb.toString();
    }
    private String getTableName(Class entityClass) {
        JoinEntity joinEntity = AnnotationUtils.getAnnotation(entityClass, JoinEntity.class);
        if (null != joinEntity) {
            return joinEntity.tableName();
        }
        throw new RuntimeException(String.format("%s is not a valid JoinEntity.", entityClass.getCanonicalName()));
    }
}
