package com.eagletsoft.framework.orm.assemble;

import com.eagletsoft.framework.orm.assemble.meta.AutoAssemble;
import com.eagletsoft.framework.orm.assemble.meta.Loader;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.annotation.Annotation;
import java.util.*;

public class BeanAssemblerHelper {
    private BeanAssemblerHelper() {

    }

    public static void assemble(Object target) throws Throwable {
        assemble(null, target);
    }

    private static void assemble(Context context, Object target) throws Throwable {
        if (null != target) {
            if (Collection.class.isAssignableFrom(target.getClass())) {
                assembleCollection((Collection)target);
            } else if (Map.class.isAssignableFrom(target.getClass())) {
                assembleCollection(((Map)target).values());
            } else {
                if (null == context) {
                    context = new Context();
                    internalAssemble(context, target);
                    context.notifyEndLoad();
                } else {
                    internalAssemble(context, target);
                }
            }
        }
    }

    private static void assembleCollection(Collection<?> ret) throws Throwable {
        Context context = new Context();
        for (Object obj : ret) {
            assemble(context, obj);
        }
        context.notifyEndLoad();
    }

    private static boolean isAssembleEnabled(Object obj) {
        boolean assembleEnabled = false;
        if (null != obj &&
                (Collection.class.isAssignableFrom(obj.getClass())
                || Map.class.isAssignableFrom(obj.getClass())
                || (null != obj.getClass().getAnnotation(AutoAssemble.class)))) {
            assembleEnabled = true;
        }
        return assembleEnabled;
    }

    private static void internalAssemble(Context context, Object target) {
        if (null != target) {
            try {
                ReflectionUtils.doWithFields(target.getClass(), f -> {
                    try {
                        ReflectionUtils.makeAccessible(f);
                        Object fieldObj = ReflectionUtils.getField(f, target);

                        if (!isAssembleEnabled(fieldObj)) {
                            Annotation[] anns = f.getAnnotations();
                            for (Annotation ann : anns) {
                                Loader loader = AnnotationUtils.getAnnotation(ann, Loader.class);
                                if (null != loader) {
                                    AssembleLoader<Annotation> assembleLoader = context.registerAutoAssembler(loader.loadedBy());
                                    assembleLoader.load(target, f, ann);
                                }
                            }
                        }
                        fieldObj = ReflectionUtils.getField(f, target);
                        if (isAssembleEnabled(fieldObj)) {
                            assemble(fieldObj);
                        }
                    } catch (Throwable t) {
                        throw new RuntimeException(t);
                    }
                });
            } catch (Throwable t) {
                System.out.println("Error happened when assembling properties.");
                throw t;
            }
        }
    }

    public static class Context {
        Set<Listener> listeners = new HashSet<>();
        Map<String, AssembleLoader<Annotation>> register = new HashMap<>();
        public interface Listener {
            void onEndLoad(Context ctx);
        }

        public AssembleLoader<Annotation> registerAutoAssembler(Class<? extends AssembleLoader> clazz) throws InstantiationException, IllegalAccessException {
            AssembleLoader<Annotation> assembleLoader = register.get(clazz.getCanonicalName());
            if (null == assembleLoader) {
                assembleLoader = clazz.newInstance();
                register.put(clazz.getCanonicalName(), assembleLoader);

                if (assembleLoader instanceof Listener) {
                    if (!listeners.contains(assembleLoader)) {
                        listeners.add((Listener) assembleLoader);
                    }
                }
            }
            return assembleLoader;
        }

        public void notifyEndLoad() {
            for (Listener listener : listeners) {
                listener.onEndLoad(this);
            }
        }
    }
}
