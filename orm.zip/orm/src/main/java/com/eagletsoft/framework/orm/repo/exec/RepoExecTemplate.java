package com.eagletsoft.framework.orm.repo.exec;

import com.eagletsoft.framework.orm.entity.meta.Id;
import com.eagletsoft.framework.orm.entity.meta.Table;
import com.eagletsoft.framework.orm.repo.naming.NamingStrategy;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ReflectionUtils;

public class RepoExecTemplate {
    protected Class entityClass;
    protected String idName;
    protected Table table;
    protected NamingStrategy namingStrategy;
    protected String profile;

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public void setNamingStrategy(NamingStrategy namingStrategy) {
        this.namingStrategy = namingStrategy;
    }

    public void setEntityClass(Class entityClass) {
        this.entityClass = entityClass;
        if (null != entityClass) {
            try {
                this.table = AnnotationUtils.getAnnotation(entityClass, Table.class);
                ReflectionUtils.doWithFields(entityClass, f->{
                    Id id = AnnotationUtils.getAnnotation(f, Id.class);
                    if (null != id) {
                        idName = f.getName();
                    }
                });
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}
