package com.eagletsoft.framework.orm.repo.exec;

import java.io.Serializable;

public interface CrudRepo<T> {
    int update(Object data);
    void create(Object data);
    int deleteById(Serializable id);
    T findById(Serializable id);
}
