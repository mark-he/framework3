package com.eagletsoft.framework.orm.assemble.meta;

import com.eagletsoft.framework.orm.assemble.AssembleLoader;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface Loader {
    Class<? extends AssembleLoader> loadedBy();
}
