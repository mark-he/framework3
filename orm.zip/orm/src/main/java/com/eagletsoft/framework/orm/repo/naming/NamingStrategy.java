package com.eagletsoft.framework.orm.repo.naming;

public interface NamingStrategy {
    String read(String name);
    String write(String name);
}
