package com.eagletsoft.framework.orm.assemble.meta;

import com.eagletsoft.framework.orm.assemble.BeanAssemblerHelper;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(300)
@Aspect
public class AutoAssembleAspect {

    @Around("@annotation(autoAssemble")
    public Object round(ProceedingJoinPoint point, AutoAssemble autoAssemble) throws Throwable {
        Object ret = point.proceed();
        BeanAssemblerHelper.assemble(ret);
        return ret;
    }
}
