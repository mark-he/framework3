package com.eagletsoft.framework.orm.assemble.meta;

import com.eagletsoft.framework.orm.assemble.AssemblePropertyLoader;
import com.eagletsoft.framework.orm.assemble.PropertyAssembler;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@Loader(loadedBy = AssemblePropertyLoader.class)
public @interface AssembleProperty {
    String[] vars() default {};
    Class<? extends PropertyAssembler> assembler();
}
