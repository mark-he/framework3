package com.eagletsoft.framework.orm.assemble;

import com.eagletsoft.framework.orm.assemble.meta.AssembleProperty;
import ognl.Ognl;
import ognl.OgnlException;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class AssemblePropertyLoader implements AssembleLoader<AssembleProperty>, BeanAssemblerHelper.Context.Listener {
    private Map<String, List<Job>> jobMap = new HashMap<>();
    private Map<String, PropertyAssembler> register = new HashMap<>();

    @Override
    public void load(Object root, Field f, AssembleProperty ann) {
        registerAssembler(ann);
        String key = ann.assembler().getCanonicalName();
        List<Job> jobs = jobMap.computeIfAbsent(key, k -> {
            List<Job> j = new LinkedList<>();
            jobMap.put(k, j);
            return j;
        });
        try {
            jobs.add(new Job(root, f, ann));
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void onEndLoad(BeanAssemblerHelper.Context ctx) {
        processJobMap();
    }

    private PropertyAssembler registerAssembler(AssembleProperty ap) {
        try {
            PropertyAssembler pa = register.get(ap.assembler().getCanonicalName());
            if (null == pa) {
                pa = ap.assembler().newInstance();
                register.put(ap.assembler().getCanonicalName(), pa);
            }
            return pa;
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    private void processJobMap() {
        for (Map.Entry<String, List<Job>> entry : jobMap.entrySet()) {
            PropertyAssembler pa = register.get(entry.getKey());

            if (pa.isPreferredBatch()) {
                List<Object[]> varList = new LinkedList<>();
                for (Job job : entry.getValue()) {
                    varList.add(job.params);
                }
                List<PropertyAssembler.BatchResult> results = pa.assemble(varList);

                if (null != results && !results.isEmpty()) {
                    for (Job job : entry.getValue()) {
                        for (PropertyAssembler.BatchResult batchResult : results) {
                            if (isArrayEqual(job.params, batchResult.getVars())) {
                                ReflectionUtils.makeAccessible(job.field);
                                ReflectionUtils.setField(job.field, job.bean, batchResult.result);
                                break;
                            }
                        }
                    }
                }
            } else {
                for (Job job : entry.getValue()) {
                    ReflectionUtils.makeAccessible(job.field);
                    Object obj = pa.assemble(job.params);
                    ReflectionUtils.setField(job.field, job.bean, obj);
                }
            }
        }
    }

    private boolean isArrayEqual(Object[] var1, Object[] var2) {
        if (var1.length == var2.length) {
            for (int i = 0; i < var1.length; i++) {
                if ((var1[i] == null && var2[i] == null)
                || (null != var1[i] && var1[i].equals(var2[i]))) {

                } else {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    private static class Job {
        Object bean;
        Field field;
        AssembleProperty ann;
        Object[] params;

        public Job(Object bean, Field field, AssembleProperty ann) throws OgnlException {
            this.bean = bean;
            this.field = field;
            this.ann = ann;
            this.params = getParamValues(bean, ann.vars());
        }

        private Object[] getParamValues(Object ret, String[] values) throws OgnlException {
            Object[] objs = new Object[values.length];
            for (int i = 0; i < values.length; i++) {
                String value = values[i];
                if (!StringUtils.isEmpty(value)) {
                    if (value.startsWith("$")) {
                        objs[i] = Ognl.getValue(value.substring(1), ret);
                    } else {
                        objs[i] = value;
                    }
                }
            }
            return objs;
        }
    }
}
