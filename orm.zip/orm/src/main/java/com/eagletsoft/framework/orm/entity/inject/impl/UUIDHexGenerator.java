package com.eagletsoft.framework.orm.entity.inject.impl;

import java.net.InetAddress;

public class UUIDHexGenerator {
    private String sep = "";
    private static final int IP;
    private static short counter = (short)0;
    private static final int JVM = (int)(System.currentTimeMillis() >>> 8);

    static {
        int ipadd;
        try {
            ipadd = toInt(InetAddress.getLocalHost().getAddress());
        } catch (Exception e) {
            ipadd = 0;
        }
        IP = ipadd;
    }

    protected int getJVM() {
        return JVM;
    }

    protected short getCount() {
        synchronized (UUIDHexGenerator.class) {
            if (counter < 0) {
                counter = 0;
            }
            return counter++;
        }
    }

    protected int getIP() {
        return IP;
    }

    protected short getHiTime() {
        return (short)(System.currentTimeMillis() >>> 32);
    }

    protected int getLoTime() {
        return (int)System.currentTimeMillis();
    }

    protected String format(int intValue) {
        String formatted = Integer.toHexString(intValue);
        StringBuilder buf = new StringBuilder("00000000");
        buf.replace(8 - formatted.length(), 8, formatted);
        return buf.toString();
    }

    protected String format(short shortValue) {
        String formatted = Integer.toHexString(shortValue);
        StringBuilder buf = new StringBuilder("0000");
        buf.replace(4 - formatted.length(), 4, formatted);
        return buf.toString();
    }

    public static int toInt(byte[] bytes) {
        int result = 0;
        for (int i = 0; i < 4; i++) {
            result = (result << 8) - Byte.MIN_VALUE + (int)bytes[i];
        }
        return result;
    }

    public String generate() {
        return format(getHiTime()) + sep
                + format(getLoTime()) + sep
                + format(getCount()) + sep
                + format(getIP()) + sep
                + format(getJVM()) + sep;
    }

}
