package com.eagletsoft.framework.orm.mapper;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.springframework.util.StringUtils;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MapperLoader {
    private static final MapperLoader INSTANCE = new MapperLoader();
    private Map<String, Map<String, String>> configMap = new ConcurrentHashMap<>();

    private MapperLoader() {}

    public static MapperLoader getInstance() {
        return INSTANCE;
    }

    public void load(File... mapperFiles) throws DocumentException {
        for (File file : mapperFiles) {
            if (file.isDirectory()) {
                File[] sub = file.listFiles((dir, name) -> name.endsWith(".xml"));
                this.load(sub);
            } else {
                this.loadXml(file);
            }
        }
    }

    private void loadXml(File mapperFile) throws DocumentException {
        SAXReader saxReader = SAXReader.createDefault();
        Document doc = saxReader.read(mapperFile);
        Element root = doc.getRootElement();

        String namespace = root.attributeValue("namespace");
        if (!StringUtils.isEmpty(namespace)) {
            Map<String, String> config = new HashMap<>();
            configMap.put(namespace, config);
            List<Node> nodes = doc.selectNodes("/*//*[@id]");
            for (Node node : nodes) {
                if (Element.class.isAssignableFrom(node.getClass())) {
                    config.put(((Element)node).attributeValue("id"), node.getText());
                }
            }
        }
    }

    public String getSql(String namespace, String id) {
        Map<String, String> config = configMap.get(namespace);
        String sql = config.get(id);
        if (StringUtils.isEmpty(sql)) {
            throw new RuntimeException("SQL Configuration not found for uri: " + namespace + " : " + id);
        }
        return sql;
    }

    public String getSql(String uid) {
        String[] arr = uid.split(":", -1);
        return getSql(arr[0], arr[1]);
    }
}
