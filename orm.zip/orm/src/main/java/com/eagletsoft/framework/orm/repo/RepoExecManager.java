package com.eagletsoft.framework.orm.repo;

import com.eagletsoft.framework.orm.repo.exec.RepoExecService;
import com.eagletsoft.framework.orm.repo.exec.impl.RepoExecAnnotationService;
import com.eagletsoft.framework.orm.repo.exec.impl.RepoExecTemplateService;
import com.eagletsoft.framework.orm.repo.exec.meta.Exec;
import com.eagletsoft.framework.orm.repo.meta.Repo;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.core.annotation.MergedAnnotations;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class RepoExecManager {
    private static RepoExecManager INSTANCE = new RepoExecManager();
    public static RepoExecManager getInstance() {
        return INSTANCE;
    }

    public Object process(Class targetClass, Method method, Object[] args) throws IllegalAccessException, InstantiationException {
        Repo repoAnn = (Repo)targetClass.getAnnotation(Repo.class);
        Annotation execAnn = findFirstExecAnn(method);

        RepoExecService executor;
        if (null != execAnn) {
            Exec exec = AnnotationUtils.getAnnotation(execAnn, Exec.class);
            RepoExecAnnotationService annotationService = exec.value().newInstance();
            annotationService.setAnnConfig(AnnotationUtils.getAnnotationAttributes(execAnn));
            annotationService.setNamingStrategy(repoAnn.namingStrategy().newInstance());
            annotationService.setProfile(repoAnn.profile());
            executor = annotationService;
        } else {
            Class entityClass = repoAnn.enetityClass();
            executor = new RepoExecTemplateService(entityClass, repoAnn.template(), repoAnn.namingStrategy().newInstance(), repoAnn.profile());
        }
        return executor.process(method, args);
    }

    private Annotation findFirstExecAnn(AnnotatedElement e) {
        List<Annotation> annotations = getAnnotations(e);
        for (Annotation ann : annotations) {
            Exec execAnn = AnnotationUtils.getAnnotation(ann, Exec.class);
            if (null != execAnn) {
                return ann;
            }
        }
        return null;
    }

    private List<Annotation> getAnnotations(AnnotatedElement e) {
        List<Annotation> ret = new ArrayList<>();
        MergedAnnotations.from(e).forEach(x -> {
           if (x.isDirectlyPresent()) {
               ret.add(x.getRoot().synthesize());
           }
        });
        return ret;
    }
}
